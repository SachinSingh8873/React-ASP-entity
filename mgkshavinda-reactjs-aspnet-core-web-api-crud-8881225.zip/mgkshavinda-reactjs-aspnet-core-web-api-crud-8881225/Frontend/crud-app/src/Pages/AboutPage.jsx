import React from 'react'
import NavMenu from '../Components/NavMenu'

const AboutPage = () => {
  return (
    <div>
        <NavMenu />
    </div>
  )
}

export default AboutPage